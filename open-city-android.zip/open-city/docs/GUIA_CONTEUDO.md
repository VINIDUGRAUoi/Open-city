# Como adicionar conteúdo

## Novo veículo
1. Abra `scripts/vehicles/vehicle_data.gd`.
2. Copie uma entrada de `TYPES`, dê um id novo (ex.: `"taxi"`) e ajuste massa, potência, tamanho e cores.
3. Adicione o id na lista `IDS` para ele aparecer no trânsito.
4. Para estacionar um perto do início, adicione uma linha em `PARKED` no `scripts/main.gd`.
Ele já é dirigível e entrável automaticamente.

## Ajuste de direção
Se um carro andar **para trás** ao acelerar, mude `ENGINE_SIGN` para `-1.0` em `scripts/vehicles/vehicle.gd`.

## Novas missões
O sistema de missões ainda não existe (Etapa 7).
