# Registro de estado (atualizado a cada etapa)

## Escrito, mas NÃO executado (sem Godot no ambiente de geração)
- Entrada configurável (teclado + gamepad) via autoload
- Jogador: andar, correr com resistência, pular, agachar (com checagem de teto), câmera 3ª pessoa com SpringArm (não atravessa paredes), vida, cura, respawn, queda no vazio
- HUD com vida, resistência, FPS e dicas
- Cidade de 36 quarteirões (praças aleatórias, prédios com colisão), avenidas, rampa e caixas de teste, sol com sombras e céu procedural
- Testes headless (`tests/run_tests.gd`)
- Controles de toque para Android (analógico flutuante, arrastar para a câmera, botões Pular/Correr/Agachar/Usar), HUD ampliado e sombras desligadas em celular
- Preset de exportação Android e fluxo do GitHub Actions (`.github/workflows/build.yml`), que também roda os testes na nuvem

## Adicionado nesta versão (também NÃO verificado em execução)
- Veículos dirigíveis (VehicleBody3D): esportivo, sedã, SUV, caminhonete, caminhão e van; entrar/sair de qualquer veículo; câmera de perseguição; dano simplificado; luz de freio
- Trânsito (carros que seguem as avenidas e freiam diante de obstáculos) e pedestres (andam pelas calçadas, fogem, caem se atingidos); ambos reciclados perto do jogador
- Mapa em tela cheia com GPS (toque para definir o destino), minimapa, marcador no mundo
- Menu de pausa com configurações de gráficos (qualidade, sombras, MSAA, distância, quantidade de NPCs, FOV, sensibilidade, limite de FPS), salvar/carregar posição e vida

## Visuais (versão atual, também NÃO verificada em execução)
- Prédios com janelas texturizadas (vidro, tijolo, concreto), térreo com lojas e toldos, recuos e equipamentos no telhado; casas com porta, janelas, telhado de duas águas e chaminé; árvores, postes de luz, faixas de pedestre e ruas com asfalto
- Pessoas articuladas (cabeça com cabelo e olhos, tronco, braços, pernas, sapatos) com animação de andar, no jogador e nos pedestres
- Carros com capô, para-brisa inclinado, vidros, faróis, lanternas, grade, para-choques, placas, retrovisores, frestas de portas, caixas de roda e rodas com aro e raios; caçamba na caminhonete, baú no caminhão, aerofólio no esportivo
- Botões na tela ao dirigir: setas de direção, Acelerar, Freio, Freio de mão e Sair

## Atualização: direção, visuais e controles (também NÃO verificada em execução)
- Carros: câmbio automático, curva de torque, arrasto, freio motor, freio de mão que solta a traseira, direção que endurece com a velocidade, desvira sozinho se capotar, som de motor e buzina (H / botão Buzina). Correção do sentido da força do motor (ENGINE_SIGN = -1)
- Carros e pessoas com formas arredondadas (carroceria por superelipse, anéis elípticos), pessoa com esqueleto e joelhos/cotovelos, uma malha por pessoa
- NPCs: papéis (caminhante, corredor, parado), mais pedestres, conversa com balão de fala (E perto de um pedestre)
- Mapa: tocar no minimapa abre o mapa (botão de cima removido). Configurações de controles e HUD (tamanho, botões, opacidade, canhoto, minimapa, dicas, inverter câmera)

## Atualização: 13 carros e skins por pasta (também NÃO verificada em execução)
- Carros novos: hatch, picape compacta, van clássica, táxi, viatura, ambulância, ônibus (pintura especial: faixas, giroflex, luz de táxi). Trânsito usa TRAFFIC_MIX; carros novos estacionados perto do início
- Skins por pasta em assets/vehicles/<id>/ (model.glb e/ou skin.png). Veja docs/SKINS.md
- Altura dos carros do trânsito agora depende do raio da roda

## Atualização: mais carros e skins por pasta (NÃO verificada em execução)
- 21 tipos de veículo (13 do conjunto anterior + cupê, perua, minivan, SUV compacto, mini urbano, cupê clássico, picape cabine dupla, micro-ônibus), todos originais gerados por código
- Pintura especial de táxi, viatura, ambulância e ônibus no `vehicle_builder.gd`; trânsito usa `TRAFFIC_MIX`; carros novos estacionados em `main.gd`
- Skins por pasta em `assets/vehicles/<id>/` (`model.glb` e/ou `skin.png`), veja `docs/SKINS.md`
- Altura do carro do trânsito agora depende do raio da roda

## Testes realizados
Nenhum. Nada foi compilado nem executado. Podem existir erros de sintaxe ou de API do Godot; o primeiro passo é abrir o projeto e me enviar a saída do editor.

## Limitações conhecidas
- Tudo é geometria procedural "low-poly" gerada em código; não é realismo fotográfico. Para modelos 3D profissionais (por exemplo .glb de bibliotecas gratuitas CC0) é preciso baixá-los e colocá-los em res://assets/; este ambiente não tem internet para isso
- Texturas repetem em padrão; não há iluminação noturna nem janelas acesas
- Sem motocicletas, sem garagem, sem som de motor/buzina, sem faróis com luz real
- Sem semáforos; trânsito pode ficar parado em cruzamentos até destravar
- Pedestres e carros do trânsito são modelos simples; sem animação de andar
- A rota do GPS é aproximada (em L pelos cruzamentos)
- Renderizador Compatibility: sem escala de resolução 3D
- Polícia, missões, interiores e ciclo dia/noite ainda não existem
- Visuais são caixas e cápsulas coloridas; sem animação de personagem
- Sem degraus automáticos (só rampas e saltos até ~1,5 m)
- Sem interiores, NPCs, veículos, polícia, missões, menus, mapa, salvamento, áudio, ciclo dia/noite ou clima
- Cidade pequena (~310 m de lado), todos os nós carregados de uma vez; sem LOD nem streaming ainda
- `interact` só emite um sinal; nada o consome ainda

## Próximo passo
Etapa 4: veículo dirigível (VehicleBody3D), entrar/sair e câmera de veículo.
