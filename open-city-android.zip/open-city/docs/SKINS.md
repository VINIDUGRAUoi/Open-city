# Skins de veículos (trocar visual por pasta)

Cada tipo de veículo tem uma pasta em `assets/vehicles/<id>/`. O `<id>` é o nome do tipo em
`scripts/vehicles/vehicle_data.gd`:

hatch, sedan, suv, pickup, small_pickup, classic_van, van, truck, taxi, police, ambulance, bus,
sport, coupe, wagon, minivan, compact_suv, mini, muscle, large_pickup, microbus

Pasta vazia = o carro continua com o visual gerado por código. Para trocar, coloque arquivos nela,
envie para o GitHub e deixe o Actions gerar o APK de novo. Não precisa mexer em código.

## Opção 1: modelo 3D completo (`model.glb`)

Coloque `assets/vehicles/<id>/model.glb` (ou `model.gltf`). O jogo troca a carroceria pelo seu modelo.

- **Tamanho:** o jogo escala o modelo sozinho para ter o comprimento do carro daquele tipo.
- **Frente:** modelos .glb normalmente olham para +Z e o jogo gira 180 graus. Se o carro aparecer de ré,
  troque `MODEL_FACES_PLUS_Z` para `false` em `scripts/vehicles/vehicle_skin.gd`.
- **Rodas:** se o modelo tiver rodas, dê a elas nomes com `wheel`, `roda`, `tire` ou `pneu`. O jogo então
  não desenha as rodas geradas por código (as rodas do modelo ficam paradas, sem girar nem esterçar).
  Sem rodas no modelo, as rodas do jogo continuam.
- **Física:** não muda. Colisão, peso e potência vêm de `vehicle_data.gd`.
- **Peso:** celular sofre com modelos pesados e o trânsito tem vários carros. Prefira até uns
  10.000 triângulos e texturas de no máximo 1024x1024.

**Modelos pesados:** se o seu `.glb` tiver mais de uns 10.000 triângulos (a maioria dos modelos do Sketchfab tem
centenas de milhares), mande para otimização antes: ele precisa de interior removido, polígonos reduzidos
e rodas separadas (nós `wheel_fl`, `wheel_fr`, `wheel_rl`, `wheel_rr`) para ficar leve no celular.

**Duas versões (opcional):** além do `model.glb` (detalhado, vale quando o carro está perto), você pode
colocar um `model_far.glb` mais leve (uns 7.000 triângulos). O jogo troca sozinho a 45 m de distância
(`FAR_DISTANCE` em `vehicle_skin.gd`). Os 4 carros que vieram prontos já têm as duas versões.

## Opção 2: imagem de pintura (`skin.png`)

Coloque `assets/vehicles/<id>/skin.png` (ou `.jpg`, `.webp`). A imagem cobre a carroceria e se repete
a cada 4 metros (`TEXTURE_TILE_METERS` em `vehicle_skin.gd`). Serve bem para padrões e cores
(camuflagem, listras, metálico). **Não alinha desenhos exatos** (portas, adesivos); para isso use
um modelo `.glb`. Com imagem, a cor sorteada do carro deixa de ser usada.

## Direitos de uso

Use só modelos e imagens que sejam seus ou de licença livre (por exemplo CC0, ou CC-BY dando o crédito).
Bibliotecas comuns: Kenney (kenney.nl), Quaternius (quaternius.com), Poly Pizza (poly.pizza).
Confira a licença de cada modelo. **Não use modelos tirados de outros jogos** (GTA, Forza etc.) nem
pacotes de mods: são material protegido, e o APK é publicado no GitHub.

## Se algo der errado

- O modelo/imagem não aparece: o Godot precisa importar o arquivo. O workflow já roda a importação;
  veja no log do Actions se há erro de import. Confira também o nome (`model.glb`, `skin.png`).
- Aviso "o modelo não tem nenhuma malha": o .glb está vazio ou só tem esqueleto.
- Modelo flutuando ou afundado: o fundo do modelo é alinhado ao chão (com rodas) ou à base da
  carroceria (sem rodas). Ajuste o modelo para a origem ficar embaixo.
