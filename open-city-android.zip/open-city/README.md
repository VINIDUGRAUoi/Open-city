# Open City — jogo 3D de mundo aberto (Godot 4)

Projeto original inspirado no gênero de mundo aberto. Não usa mapas, marcas,
personagens nem recursos de nenhum jogo existente.

**Estado atual: personagem, cidade, veículos dirigíveis, pedestres, trânsito, mapa/GPS, menu de pausa e configurações, salvamento simples.**
Todo o código foi escrito, mas **ainda não foi executado** (o ambiente onde foi
gerado não tem o Godot). Veja `docs/REGISTRO.md`.

## Como abrir e executar
1. Instale o **Godot 4.3 ou superior** (versão "standard", sem .NET): https://godotengine.org/download
2. No gerenciador de projetos, clique em **Importar** e escolha o arquivo `project.godot`.
3. Abra o projeto uma vez no editor (ele gera o cache de scripts) e aperte **F5**.
4. Se aparecer algum erro no painel "Saída/Depurador", copie e me envie: corrijo na próxima etapa.

## Controles (registrados em `scripts/core/input_setup.gd`)
| Ação | Teclado/Mouse | Gamepad |
|---|---|---|
| Mover | W A S D / setas | Analógico esquerdo |
| Câmera | Mouse | Analógico direito |
| Correr | Shift | Clique no analógico esquerdo |
| Pular (a pé) / freio de mão (no carro) | Espaço | A |
| Agachar (segurar) | C / Ctrl | B |
| Interagir / entrar e sair de veículo | E | X |
| Mapa | M | Back |
| Menu de pausa / configurações | Esc | Start |
| Dano de teste (-10 vida) | K | — |

Para mudar uma tecla, edite `KEY_BINDINGS` no `input_setup.gd`. O menu de
configuração de controles entra na Etapa 8.

## Testes automatizados
```
godot --headless --path . -s tests/run_tests.gd
```
Verifica ações de entrada, vida/cura/morte do jogador e geração determinística do mundo.

## Requisitos mínimos (alvo)
- Godot 4.3+, GPU com OpenGL 3.3 (renderizador "Compatibility", escolhido por rodar em hardware modesto).
- 4 GB de RAM. Para visuais melhores no futuro, dá para migrar para o renderizador "Forward+" em Configurações do Projeto.

## Dependências externas
Nenhuma além do Godot. Todos os visuais são **placeholders geométricos**; sem texturas, modelos, sons ou músicas.

## Estrutura
Veja `docs/ARQUITETURA.md`.

## Dirigindo
Chegue perto de qualquer veículo (estacionado ou do trânsito) e use **E**. W/S acelera e freia/ré, A/D dirige, Espaço é o freio de mão. No celular, use o analógico (para cima acelera, para baixo freia/ré, para os lados dirige) e os botões Usar e Pular. Veja `docs/GUIA_CONTEUDO.md`.
