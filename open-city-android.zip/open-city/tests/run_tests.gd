extends SceneTree
## Testes headless simples (sem dependências externas).
## Execute:  godot --headless --path . -s tests/run_tests.gd
## Código de saída 0 = tudo certo, 1 = alguma falha.

const InputScript := preload("res://scripts/core/input_setup.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const WorldScript := preload("res://scripts/world/world_builder.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const PedScript := preload("res://scripts/ai/pedestrian.gd")
const TrafficScript := preload("res://scripts/ai/traffic_car.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")
const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const TexScript := preload("res://scripts/world/textures.gd")
const GeoScript := preload("res://scripts/core/geo.gd")
const SkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")

var _failures := 0


func _initialize() -> void:
    _test_input_actions()
    _test_player_health()
    _test_world_builder()
    _test_city_graph()
    _test_vehicle_data()
    _test_vehicle_skins()
    _test_vehicle()
    _test_npcs()
    _test_visuals()
    print("Resultado: ", "TUDO OK" if _failures == 0 else "%d falha(s)" % _failures)
    quit(1 if _failures > 0 else 0)


func _check(condition: bool, label: String) -> void:
    if condition:
        print("  [ok]    ", label)
    else:
        print("  [FALHA] ", label)
        _failures += 1


func _test_input_actions() -> void:
    print("Entrada")
    InputScript.register()
    InputScript.register() # idempotência
    for action in ["move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "crouch", "interact", "pause", "map", "look_left"]:
        _check(InputMap.has_action(action), "ação registrada: " + action)
    _check(InputMap.action_get_events("jump").size() == 2, "jump tem teclado + gamepad sem duplicar")


func _test_player_health() -> void:
    print("Jogador")
    var player := PlayerScript.new()
    player.spawn_position = Vector3(0.0, 0.1, 0.0)
    root.add_child(player)
    var deaths := [0]
    player.died.connect(func() -> void: deaths[0] += 1)

    player.take_damage(30.0)
    _check(is_equal_approx(player.health, 70.0), "dano reduz a vida")
    player.take_damage(-5.0)
    _check(is_equal_approx(player.health, 70.0), "dano negativo é ignorado")
    player.heal(1000.0)
    _check(is_equal_approx(player.health, player.max_health), "cura respeita o máximo")
    player.take_damage(1000.0)
    _check(deaths[0] == 1, "morte emite sinal uma vez")
    _check(is_equal_approx(player.health, player.max_health), "respawn restaura a vida")
    player.queue_free()


func _test_world_builder() -> void:
    print("Mundo")
    var world := WorldScript.new()
    root.add_child(world)
    world.build()
    var side := WorldScript.GRID_MAX - WorldScript.GRID_MIN + 1
    var blocks := side * side
    _check(world.building_count >= (blocks - world.park_count) * 4, "pelo menos 4 construções por quarteirão não-praça")
    _check(world.get_child_count() > 40, "cria malhas de quarteirões, ruas e chão")
    _check(world.building_rects.size() == world.building_count, "dados do mapa: um retângulo por prédio")
    _check(world.park_rects.size() == world.park_count, "dados do mapa: um retângulo por praça")
    var again := WorldScript.new()
    root.add_child(again)
    again.build()
    _check(again.building_count == world.building_count, "geração é determinística")
    world.queue_free()
    again.queue_free()


func _test_city_graph() -> void:
    print("Grafo da cidade")
    _check(WorldScript.BLOCK_SIZE + WorldScript.ROAD_WIDTH == GraphScript.PITCH, "constantes batem com o world_builder")
    var ok := true
    for i in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
        for j in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
            for c in 4:
                var neighbors := GraphScript.ped_neighbors(i, j, c)
                if neighbors.size() < 2:
                    ok = false
                for n: Vector3i in neighbors:
                    if not GraphScript.block_in_range(n.x, n.y):
                        ok = false
    _check(ok, "todo canto de calçada tem vizinhos válidos")
    var a := GraphScript.ped_corner_pos(0, 0, 1)
    var cross := GraphScript.ped_neighbors(0, 0, 1)
    var crossing_ok := false
    for n: Vector3i in cross:
        if n.x != 0 or n.y != 0:
            var b := GraphScript.ped_corner_pos(n.x, n.y, n.z)
            crossing_ok = absf(a.distance_to(b) - 7.0) < 0.01
    _check(crossing_ok, "travessia de rua tem 7 m")
    var route := GraphScript.route(Vector2(5.0, 5.0), Vector2(-100.0, 90.0))
    _check(route.size() == 7, "rota do GPS tem 7 pontos")
    _check(route[0] == Vector2(5.0, 5.0) and route[6] == Vector2(-100.0, 90.0), "rota começa e termina nos pontos pedidos")
    var starts := GraphScript.traffic_starts_in_range(Vector3.ZERO, 0.0, 400.0)
    _check(starts.size() == 2 * 7 * 6 * 2, "trechos de via: 168 (7x6 em cada eixo, 2 sentidos)")


func _test_vehicle_data() -> void:
    print("Dados dos veículos")
    for id: String in DataScript.IDS:
        var d: Dictionary = DataScript.TYPES[id]
        var complete := true
        for key in ["name", "mass", "power", "awd", "max_speed", "steer", "size", "cabin", "cabin_z", "wheel_radius", "suspension", "colors"]:
            if not d.has(key):
                complete = false
        _check(complete, "tipo completo: " + id)


func _test_vehicle_skins() -> void:
    print("Skins de veículos")
    for id: String in DataScript.IDS:
        _check(str(DataScript.TYPES[id].get("id", "")) == id, "campo id confere: " + id)
    for id: String in DataScript.TRAFFIC_MIX:
        _check(DataScript.TYPES.has(id), "trânsito usa tipo existente: " + id)
    _check(SkinScript.texture_for("nao_existe") == null, "sem imagem de skin devolve null")
    _check(not SkinScript.has_model("nao_existe"), "sem modelo de skin devolve falso")
    _check(not SkinScript.has_own_wheels("nao_existe"), "sem modelo, sem rodas próprias")


func _test_vehicle() -> void:
    print("Veículo")
    var vehicle = FactoryScript.create("sedan")
    root.add_child(vehicle)
    var wheels := 0
    for child in vehicle.get_children():
        if child is VehicleWheel3D:
            wheels += 1
    _check(wheels == 4, "tem 4 rodas")
    _check(vehicle.is_in_group("enterable") and vehicle.is_in_group("vehicles"), "está nos grupos enterable/vehicles")
    _check(vehicle.can_enter(), "livre pode ser ocupado")
    var player := PlayerScript.new()
    root.add_child(player)
    vehicle.set_driver(player)
    _check(not vehicle.can_enter(), "ocupado não pode ser ocupado de novo")
    vehicle.clear_driver()
    _check(vehicle.can_enter(), "libera ao sair")
    var unknown = FactoryScript.create("tipo_inexistente")
    root.add_child(unknown)
    _check(unknown.type_id == "sedan", "tipo desconhecido vira sedan")
    vehicle.queue_free()
    unknown.queue_free()
    player.queue_free()


func _test_npcs() -> void:
    print("NPCs")
    var ped = PedScript.new()
    ped.place(Vector3i(0, 0, 0))
    root.add_child(ped)
    _check(ped.target != Vector3.ZERO, "pedestre escolhe um destino")
    ped.queue_free()
    var car = TrafficScript.new()
    car.setup("suv", Color(0.2, 0.2, 0.2))
    car.start(0, 0, Vector2i(1, 0))
    root.add_child(car)
    _check(car.can_enter() and car.get_display_name() == "SUV", "carro do trânsito é entrável")
    car.queue_free()


func _test_visuals() -> void:
    print("Visuais")
    var holder := Node3D.new()
    root.add_child(holder)
    var rig := HumanoidScript.build(holder, HumanoidScript.random_outfit())
    var skeleton: Skeleton3D = rig["skeleton"]
    _check(skeleton.get_bone_count() == 11, "pessoa tem esqueleto com 11 ossos")
    HumanoidScript.animate(rig, 1.0, 1.0)
    _check(skeleton.get_bone_pose_rotation(HumanoidScript.THIGH_L).get_angle() > 0.1, "animação de andar mexe a coxa")
    _check(skeleton.get_bone_pose_rotation(HumanoidScript.SHIN_L).get_angle() > 0.01, "animação dobra o joelho")
    for id: String in DataScript.IDS:
        var car := Node3D.new()
        holder.add_child(car)
        var parts := BuilderScript.build(car, DataScript.TYPES[id], Color.RED, true)
        var meshes := 0
        for child in car.get_children():
            if child is MeshInstance3D:
                meshes += 1
        _check(parts.has("body_mat") and meshes >= 5, "carro detalhado montado: " + id)
    for tex_name in ["facade_glass", "facade_brick", "facade_concrete", "storefront", "house_wall", "roof_tile", "asphalt", "grass", "concrete"]:
        _check(TexScript.texture(tex_name).get_width() > 0, "textura gerada: " + tex_name)
    var st := GeoScript.new_st()
    GeoScript.box(st, Vector3.ZERO, Vector3.ONE, Vector2.ONE, 0.0, Color.WHITE)
    _check(GeoScript.has_data(st), "geometria de caixa gera triângulos")
    holder.queue_free()
