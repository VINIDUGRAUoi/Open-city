extends RefCounted
## Salvamento simples em JSON (user://savegame.json): posição, vida e destino do GPS.

const PATH := "user://savegame.json"


static func save(player: Node3D) -> bool:
    var p := player.global_position
    var data := {
        "version": 1,
        "pos": [p.x, p.y, p.z],
        "health": player.health,
        "waypoint": [GameState.waypoint.x, GameState.waypoint.y] if GameState.has_waypoint else null,
    }
    var file := FileAccess.open(PATH, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(data))
    return true


static func load_into(player: Node3D) -> bool:
    if not FileAccess.file_exists(PATH):
        return false
    var file := FileAccess.open(PATH, FileAccess.READ)
    if file == null:
        return false
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        return false
    var data: Dictionary = parsed
    var pos: Variant = data.get("pos")
    if not (pos is Array) or pos.size() != 3:
        return false
    player.teleport(Vector3(float(pos[0]), float(pos[1]) + 0.5, float(pos[2])))
    player.set_health(float(data.get("health", player.max_health)))
    var wp: Variant = data.get("waypoint")
    if wp is Array and wp.size() == 2:
        GameState.set_waypoint(Vector2(float(wp[0]), float(wp[1])))
        GameState.update_route(Vector2(player.global_position.x, player.global_position.z))
    else:
        GameState.clear_waypoint()
    return true
