extends CanvasLayer
## Celular do jogador: loja simples de armas e concessionária com compra e spawn de veículos.
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

var player: Node3D
var game_root: Node3D
var money := 15000
var owned_weapons := {"punhos": true}
var owned_cars := {}
var selected_car := "hatch"
var _panel: PanelContainer
var _status: Label
var _money_label: Label
var _cars_list: VBoxContainer
var _weapons_list: VBoxContainer

const WEAPONS := {
    "punhos": {"label": "Punhos", "price": 0},
    "pistola": {"label": "Pistola", "price": 800},
    "rifle": {"label": "Rifle", "price": 2200},
    "escopeta": {"label": "Escopeta", "price": 1600}
}
const CARS := ["hatch", "sedan", "suv", "pickup", "sport", "coupe", "muscle", "large_pickup"]

func _ready() -> void:
    layer = 20
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    var phone_button := Button.new()
    phone_button.text = "CELULAR"
    phone_button.position = Vector2(-150, 18)
    phone_button.size = Vector2(128, 48)
    phone_button.anchor_left = 1.0
    phone_button.anchor_right = 1.0
    phone_button.pressed.connect(toggle_phone)
    root.add_child(phone_button)

    _panel = PanelContainer.new()
    _panel.set_anchors_preset(Control.PRESET_CENTER)
    _panel.position = Vector2(-240, -300)
    _panel.size = Vector2(480, 600)
    _panel.custom_minimum_size = Vector2(480, 600)
    _panel.visible = false
    root.add_child(_panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 8)
    _panel.add_child(column)
    var title := Label.new()
    title.text = "📱 CELULAR — OPEN CITY"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 22)
    column.add_child(title)
    _money_label = Label.new()
    column.add_child(_money_label)
    var close := Button.new()
    close.text = "Fechar celular"
    close.pressed.connect(toggle_phone)
    column.add_child(close)
    var tabs := HBoxContainer.new()
    column.add_child(tabs)
    var weapons_tab := Button.new()
    weapons_tab.text = "Loja de armas"
    weapons_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    weapons_tab.pressed.connect(_show_weapons)
    tabs.add_child(weapons_tab)
    var cars_tab := Button.new()
    cars_tab.text = "Concessionária"
    cars_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    cars_tab.pressed.connect(_show_cars)
    tabs.add_child(cars_tab)
    _status = Label.new()
    _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    column.add_child(_status)
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    column.add_child(scroll)
    var lists := VBoxContainer.new()
    lists.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(lists)
    _weapons_list = VBoxContainer.new()
    _weapons_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    lists.add_child(_weapons_list)
    _cars_list = VBoxContainer.new()
    _cars_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    lists.add_child(_cars_list)
    _show_weapons()
    _refresh_money()

func toggle_phone() -> void:
    _panel.visible = not _panel.visible
    if _panel.visible:
        get_tree().paused = false

func _refresh_money() -> void:
    _money_label.text = "Dinheiro: $%d" % money

func _show_weapons() -> void:
    _weapons_list.visible = true
    _cars_list.visible = false
    for child in _weapons_list.get_children():
        child.queue_free()
    for id in WEAPONS:
        var item: Dictionary = WEAPONS[id]
        var button := Button.new()
        var owned: bool = owned_weapons.has(id)
        button.text = "%s — %s" % [item.label, "Selecionar" if owned else "$%d — Comprar" % item.price]
        button.custom_minimum_size.y = 48
        button.pressed.connect(func(): _choose_weapon(id))
        _weapons_list.add_child(button)
    var use_button := Button.new()
    use_button.text = "USAR ARMA SELECIONADA (F / botão de ataque)"
    use_button.pressed.connect(_use_weapon)
    _weapons_list.add_child(use_button)

func _choose_weapon(id: String) -> void:
    var item: Dictionary = WEAPONS[id]
    if not owned_weapons.has(id):
        if money < int(item.price):
            _status.text = "Dinheiro insuficiente."
            return
        money -= int(item.price)
        owned_weapons[id] = true
    if player != null:
        player.selected_weapon = id
    _status.text = "Selecionado: %s. Aponte para um NPC e use o botão de ataque." % item.label
    _refresh_money()
    _show_weapons()

func _use_weapon() -> void:
    if player != null:
        player.use_selected_weapon()

func _show_cars() -> void:
    _weapons_list.visible = false
    _cars_list.visible = true
    for child in _cars_list.get_children():
        child.queue_free()
    for id in CARS:
        if not DataScript.TYPES.has(id):
            continue
        var data: Dictionary = DataScript.TYPES[id]
        var price := _car_price(id)
        var button := Button.new()
        button.text = "%s — %s" % [data.name, "Spawn" if owned_cars.has(id) else "$%d — Comprar" % price]
        button.custom_minimum_size.y = 48
        button.pressed.connect(func(): _buy_or_spawn_car(id))
        _cars_list.add_child(button)

func _car_price(id: String) -> int:
    var data: Dictionary = DataScript.TYPES[id]
    var speed: float = float(data.get("max_speed", 30.0))
    return int(1800 + speed * 100 + float(data.get("power", 1500.0)) * 0.25)

func _buy_or_spawn_car(id: String) -> void:
    if not owned_cars.has(id):
        var price := _car_price(id)
        if money < price:
            _status.text = "Dinheiro insuficiente para esse veículo."
            return
        money -= price
        owned_cars[id] = true
        _status.text = "Veículo comprado! Você pode solicitar o spawn novamente pelo celular."
        _refresh_money()
        _show_cars()
        return
    if player == null or game_root == null:
        _status.text = "Não foi possível criar o veículo agora."
        return
    if player.is_driving():
        _status.text = "Saia do veículo atual antes de solicitar outro."
        return
    var forward: Vector2 = player.get_forward_xz()
    var car: Node3D = FactoryScript.create(id)
    game_root.add_child(car)
    car.global_position = player.global_position + Vector3(forward.x, 0.0, forward.y) * 6.0 + Vector3.UP * 1.0
    car.rotation.y = atan2(-forward.x, -forward.y)
    _status.text = "%s criado perto de você. Aproxime-se e toque em Usar para entrar." % DataScript.TYPES[id].name
