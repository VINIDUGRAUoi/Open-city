extends CanvasLayer
## Menu de pausa (Esc / botão "Menu"): continuar, mapa, configurações, salvar/carregar, sair.
## Também abre/fecha o mapa com a ação "map".

const SaveScript := preload("res://scripts/save/save_game.gd")

var player: Node3D
var map_screen: Node

var is_open := false

var _main_box: VBoxContainer
var _settings_scroll: ScrollContainer
var _message: Label
var _quality: OptionButton
var _shadows: CheckBox
var _msaa: OptionButton
var _view_distance: HSlider
var _peds: HSlider
var _traffic: HSlider
var _fov: HSlider
var _sens: HSlider
var _fps: OptionButton
var _show_fps: CheckBox
var _hud_scale: HSlider
var _touch_scale: HSlider
var _touch_opacity: HSlider
var _left_handed: CheckBox
var _show_minimap: CheckBox
var _show_hints: CheckBox
var _invert_y: CheckBox
var _labels := {}


func _ready() -> void:
    layer = 9
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false

    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var theme := Theme.new()
    theme.default_font_size = 22
    root.theme = theme

    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, 0.7)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var panel := PanelContainer.new()
    center.add_child(panel)
    var margin := MarginContainer.new()
    for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
        margin.add_theme_constant_override(side, 16)
    panel.add_child(margin)
    var stack := VBoxContainer.new()
    stack.custom_minimum_size = Vector2(620.0, 0.0)
    margin.add_child(stack)

    _build_main(stack)
    _build_settings(stack)
    _message = Label.new()
    _message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    stack.add_child(_message)


func _button(parent: Control, text: String, callback: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0.0, 52.0)
    b.pressed.connect(callback)
    parent.add_child(b)
    return b


func _build_main(parent: Control) -> void:
    _main_box = VBoxContainer.new()
    parent.add_child(_main_box)
    var title := Label.new()
    title.text = "PAUSA"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _main_box.add_child(title)
    _button(_main_box, "Continuar", close)
    _button(_main_box, "Mapa", _open_map)
    _button(_main_box, "Configurações", _show_settings)
    _button(_main_box, "Salvar jogo", _save)
    _button(_main_box, "Carregar jogo", _load)
    _button(_main_box, "Sair do jogo", func() -> void: get_tree().quit())


func _row(parent: Control, text: String) -> HBoxContainer:
    var row := HBoxContainer.new()
    var label := Label.new()
    label.text = text
    label.custom_minimum_size = Vector2(250.0, 0.0)
    row.add_child(label)
    parent.add_child(row)
    return row


func _slider(parent: Control, text: String, lo: float, hi: float, step: float, on_change: Callable) -> HSlider:
    var row := _row(parent, text)
    var s := HSlider.new()
    s.min_value = lo
    s.max_value = hi
    s.step = step
    s.custom_minimum_size = Vector2(230.0, 36.0)
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    row.add_child(s)
    var value_label := Label.new()
    value_label.custom_minimum_size = Vector2(60.0, 0.0)
    row.add_child(value_label)
    _labels[s] = value_label
    s.value_changed.connect(func(v: float) -> void:
        value_label.text = str(snappedf(v, step))
        on_change.call(v)
    )
    return s


func _build_settings(parent: Control) -> void:
    _settings_scroll = ScrollContainer.new()
    _settings_scroll.custom_minimum_size = Vector2(0.0, 400.0)
    _settings_scroll.visible = false
    parent.add_child(_settings_scroll)
    var box := VBoxContainer.new()
    box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _settings_scroll.add_child(box)

    var title := Label.new()
    title.text = "CONFIGURAÇÕES"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(title)

    var row := _row(box, "Qualidade gráfica")
    _quality = OptionButton.new()
    for q in ["Baixa", "Média", "Alta"]:
        _quality.add_item(q)
    _quality.item_selected.connect(func(i: int) -> void:
        GameSettings.apply_preset(["baixa", "media", "alta"][i])
        _refresh()
    )
    row.add_child(_quality)

    row = _row(box, "Sombras")
    _shadows = CheckBox.new()
    _shadows.toggled.connect(func(on: bool) -> void:
        GameSettings.shadows = on
        GameSettings.apply()
    )
    row.add_child(_shadows)

    row = _row(box, "Antisserrilhado (MSAA)")
    _msaa = OptionButton.new()
    for q in ["Desligado", "2x", "4x"]:
        _msaa.add_item(q)
    _msaa.item_selected.connect(func(i: int) -> void:
        GameSettings.msaa = [0, 2, 4][i]
        GameSettings.apply()
    )
    row.add_child(_msaa)

    _view_distance = _slider(box, "Distância de visão (m)", 80.0, 600.0, 10.0, func(v: float) -> void:
        GameSettings.view_distance = v
        GameSettings.apply()
    )
    _peds = _slider(box, "Pedestres", 0.0, 60.0, 1.0, func(v: float) -> void:
        GameSettings.ped_count = int(v)
    )
    _traffic = _slider(box, "Carros no trânsito", 0.0, 40.0, 1.0, func(v: float) -> void:
        GameSettings.traffic_count = int(v)
    )
    _fov = _slider(box, "Campo de visão", 60.0, 100.0, 1.0, func(v: float) -> void:
        GameSettings.fov = v
        GameSettings.apply()
    )
    _sens = _slider(box, "Sensibilidade da câmera", 0.3, 3.0, 0.1, func(v: float) -> void:
        GameSettings.sensitivity = v
        GameSettings.apply()
    )

    row = _row(box, "Limite de FPS")
    _fps = OptionButton.new()
    for q in ["30", "60", "Sem limite"]:
        _fps.add_item(q)
    _fps.item_selected.connect(func(i: int) -> void:
        GameSettings.max_fps = [30, 60, 0][i]
        GameSettings.apply()
    )
    row.add_child(_fps)

    row = _row(box, "Mostrar FPS")
    _show_fps = CheckBox.new()
    _show_fps.toggled.connect(func(on: bool) -> void: GameSettings.show_fps = on)
    row.add_child(_show_fps)

    var section := Label.new()
    section.text = "CONTROLES E HUD"
    section.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(section)

    _hud_scale = _slider(box, "Tamanho do HUD", 0.7, 1.6, 0.1, func(v: float) -> void:
        GameSettings.hud_scale = v
        GameSettings.apply()
    )
    _touch_scale = _slider(box, "Tamanho dos botões", 0.7, 1.5, 0.1, func(v: float) -> void:
        GameSettings.touch_scale = v
        GameSettings.apply()
    )
    _touch_opacity = _slider(box, "Opacidade dos botões", 0.3, 1.0, 0.05, func(v: float) -> void:
        GameSettings.touch_opacity = v
        GameSettings.apply()
    )
    row = _row(box, "Modo canhoto (espelhar botões)")
    _left_handed = CheckBox.new()
    _left_handed.toggled.connect(func(on: bool) -> void:
        GameSettings.left_handed = on
        GameSettings.apply()
    )
    row.add_child(_left_handed)
    row = _row(box, "Mostrar minimapa")
    _show_minimap = CheckBox.new()
    _show_minimap.toggled.connect(func(on: bool) -> void:
        GameSettings.show_minimap = on
        GameSettings.apply()
    )
    row.add_child(_show_minimap)
    row = _row(box, "Mostrar dicas de controle")
    _show_hints = CheckBox.new()
    _show_hints.toggled.connect(func(on: bool) -> void:
        GameSettings.show_hints = on
        GameSettings.apply()
    )
    row.add_child(_show_hints)
    row = _row(box, "Inverter câmera (vertical)")
    _invert_y = CheckBox.new()
    _invert_y.toggled.connect(func(on: bool) -> void:
        GameSettings.invert_y = on
        GameSettings.apply()
    )
    row.add_child(_invert_y)

    _button(box, "Voltar", _hide_settings)


func _refresh() -> void:
    _quality.select(["baixa", "media", "alta"].find(GameSettings.quality))
    _shadows.set_pressed_no_signal(GameSettings.shadows)
    _msaa.select([0, 2, 4].find(GameSettings.msaa))
    _fps.select([30, 60, 0].find(GameSettings.max_fps))
    _show_fps.set_pressed_no_signal(GameSettings.show_fps)
    _set_slider(_view_distance, GameSettings.view_distance)
    _set_slider(_peds, float(GameSettings.ped_count))
    _set_slider(_traffic, float(GameSettings.traffic_count))
    _set_slider(_fov, GameSettings.fov)
    _set_slider(_sens, GameSettings.sensitivity)
    _set_slider(_hud_scale, GameSettings.hud_scale)
    _set_slider(_touch_scale, GameSettings.touch_scale)
    _set_slider(_touch_opacity, GameSettings.touch_opacity)
    _left_handed.set_pressed_no_signal(GameSettings.left_handed)
    _show_minimap.set_pressed_no_signal(GameSettings.show_minimap)
    _show_hints.set_pressed_no_signal(GameSettings.show_hints)
    _invert_y.set_pressed_no_signal(GameSettings.invert_y)


func _set_slider(s: HSlider, value: float) -> void:
    s.set_value_no_signal(value)
    (_labels[s] as Label).text = str(snappedf(value, s.step))


# ---------------------------------------------------------------- abrir/fechar

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause"):
        if map_screen != null and map_screen.is_open:
            map_screen.close()
        elif is_open:
            close()
        else:
            open()
        get_viewport().set_input_as_handled()
    elif event.is_action_pressed("map"):
        if is_open:
            return
        if map_screen != null:
            if map_screen.is_open:
                map_screen.close()
            else:
                map_screen.open()
        get_viewport().set_input_as_handled()


func open() -> void:
    is_open = true
    visible = true
    _hide_settings()
    _message.text = ""
    GameState.set_paused(true)


func close() -> void:
    GameSettings.save_settings()
    is_open = false
    visible = false
    GameState.set_paused(false)


func _open_map() -> void:
    close()
    if map_screen != null:
        map_screen.open()


func _show_settings() -> void:
    _refresh()
    _main_box.visible = false
    _settings_scroll.visible = true


func _hide_settings() -> void:
    _settings_scroll.visible = false
    _main_box.visible = true
    GameSettings.save_settings()


func _save() -> void:
    _message.text = "Jogo salvo." if (player != null and SaveScript.save(player)) else "Não foi possível salvar."


func _load() -> void:
    if player != null and SaveScript.load_into(player):
        close()
    else:
        _message.text = "Nenhum jogo salvo encontrado."
