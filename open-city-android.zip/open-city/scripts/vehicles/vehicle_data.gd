extends RefCounted
## Definições dos veículos. Formas, cores e pinturas inspiradas nos carros mais comuns nas
## ruas do Brasil (hatch compacto, sedã médio, picapes, vans, táxi, viatura, ambulância,
## ônibus...), sem logotipos nem nomes de marcas. Para criar um novo, adicione uma entrada
## em TYPES e o id em IDS. Veja docs/GUIA_CONTEUDO.md.
## size = carroceria baixa (largura, altura, comprimento); cabin = cabine; cabin_z < 0 = mais à frente.
## sill = altura (y) da parte de baixo da carroceria; power = força por roda motriz;
## max_speed em m/s; steer em radianos; gears = marchas. hood/trunk = fração do comprimento
## do capô/porta-malas. box = carroceria reta; bed = caçamba; cargo = baú; spoiler = aerofólio;
## livery = pintura especial (police, taxi, ambulance, bus). id = nome da pasta de skins
## (assets/vehicles/<id>/), veja docs/SKINS.md.

const IDS := ["hatch", "sedan", "suv", "pickup", "small_pickup", "classic_van", "van", "truck", "taxi", "police", "ambulance", "bus", "sport", "coupe", "wagon", "minivan", "compact_suv", "mini", "muscle", "large_pickup", "microbus"]

## Sorteio do trânsito (repetições = mais comum), como nas ruas brasileiras.
const TRAFFIC_MIX := ["hatch", "hatch", "hatch", "hatch", "hatch", "sedan", "sedan", "sedan", "suv", "suv", "pickup", "small_pickup", "small_pickup",
    "classic_van", "van", "taxi", "taxi", "taxi", "truck", "bus", "bus", "police", "ambulance", "sport",
    "coupe", "wagon", "minivan", "minivan", "compact_suv", "compact_suv", "mini", "mini", "muscle", "large_pickup", "microbus"]

const TYPES := {
    "hatch": {
        "id": "hatch",
        "name": "Hatch compacto", "mass": 1000.0, "power": 2000.0, "gears": 5, "awd": false, "max_speed": 38.0, "steer": 0.52,
        "size": Vector3(1.7, 0.55, 3.9), "cabin": Vector3(1.45, 0.55, 2.0), "cabin_z": 0.2, "sill": -0.7,
        "hood": 0.2, "trunk": 0.06,
        "wheel_radius": 0.32, "suspension": 38.0,
        "colors": [Color(0.75, 0.76, 0.78), Color(0.93, 0.93, 0.94), Color(0.07, 0.07, 0.08), Color(0.35, 0.36, 0.38), Color(0.65, 0.06, 0.06), Color(0.75, 0.76, 0.78), Color(0.93, 0.93, 0.94)],
    },
    "sedan": {
        "id": "sedan",
        "name": "Sedã médio", "mass": 1300.0, "power": 2500.0, "gears": 5, "awd": false, "max_speed": 42.0, "steer": 0.5,
        "size": Vector3(1.8, 0.62, 4.5), "cabin": Vector3(1.55, 0.58, 2.3), "cabin_z": 0.15, "sill": -0.7,
        "hood": 0.26, "trunk": 0.18,
        "wheel_radius": 0.34, "suspension": 40.0,
        "colors": [Color(0.75, 0.76, 0.78), Color(0.93, 0.93, 0.94), Color(0.07, 0.07, 0.08), Color(0.35, 0.36, 0.38), Color(0.1, 0.18, 0.4), Color(0.75, 0.76, 0.78), Color(0.07, 0.07, 0.08)],
    },
    "suv": {
        "id": "suv",
        "name": "SUV", "mass": 1900.0, "power": 3200.0, "gears": 5, "awd": true, "max_speed": 39.0, "steer": 0.45,
        "size": Vector3(2.0, 0.82, 4.7), "cabin": Vector3(1.8, 0.62, 2.9), "cabin_z": 0.35, "sill": -0.62,
        "hood": 0.2, "trunk": 0.06,
        "wheel_radius": 0.4, "suspension": 40.0,
        "colors": [Color(0.75, 0.76, 0.78), Color(0.07, 0.07, 0.08), Color(0.93, 0.93, 0.94), Color(0.35, 0.36, 0.38)],
    },
    "pickup": {
        "id": "pickup",
        "name": "Picape média", "mass": 2000.0, "power": 3000.0, "gears": 5, "awd": true, "max_speed": 39.0, "steer": 0.45,
        "size": Vector3(2.0, 0.8, 5.2), "cabin": Vector3(1.8, 0.62, 1.7), "cabin_z": -0.75, "sill": -0.6,
        "hood": 0.2, "trunk": 0.05, "bed": true,
        "wheel_radius": 0.4, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.75, 0.76, 0.78), Color(0.07, 0.07, 0.08), Color(0.35, 0.36, 0.38)],
    },
    "small_pickup": {
        "id": "small_pickup",
        "name": "Picape compacta", "mass": 1300.0, "power": 2300.0, "gears": 5, "awd": false, "max_speed": 36.0, "steer": 0.5,
        "size": Vector3(1.7, 0.68, 4.5), "cabin": Vector3(1.5, 0.55, 1.5), "cabin_z": -0.65, "sill": -0.64,
        "hood": 0.22, "trunk": 0.05, "bed": true,
        "wheel_radius": 0.34, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.65, 0.06, 0.06), Color(0.75, 0.76, 0.78), Color(0.1, 0.25, 0.5)],
    },
    "classic_van": {
        "id": "classic_van",
        "name": "Van clássica", "mass": 1500.0, "power": 2000.0, "gears": 4, "awd": false, "max_speed": 30.0, "steer": 0.5,
        "size": Vector3(1.7, 0.85, 4.1), "cabin": Vector3(1.65, 0.95, 3.0), "cabin_z": 0.1, "sill": -0.66,
        "box": true,
        "wheel_radius": 0.34, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.95, 0.9, 0.55), Color(0.2, 0.55, 0.55)],
    },
    "van": {
        "id": "van",
        "name": "Van de serviço", "mass": 2200.0, "power": 2600.0, "gears": 5, "awd": false, "max_speed": 33.0, "steer": 0.45,
        "size": Vector3(2.0, 0.92, 5.0), "cabin": Vector3(1.9, 0.9, 3.7), "cabin_z": 0.35, "sill": -0.64,
        "box": true,
        "wheel_radius": 0.38, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.93, 0.93, 0.94), Color(0.9, 0.8, 0.1)],
    },
    "truck": {
        "id": "truck",
        "name": "Caminhão baú", "mass": 5000.0, "power": 5500.0, "gears": 4, "awd": true, "max_speed": 28.0, "steer": 0.4,
        "size": Vector3(2.5, 1.0, 7.0), "cabin": Vector3(2.3, 1.2, 2.0), "cabin_z": -2.4, "sill": -0.46,
        "box": true, "cargo": true,
        "wheel_radius": 0.5, "suspension": 35.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.2, 0.4, 0.7), Color(0.8, 0.5, 0.1)],
    },
    "taxi": {
        "id": "taxi",
        "name": "Táxi", "mass": 1300.0, "power": 2500.0, "gears": 5, "awd": false, "max_speed": 42.0, "steer": 0.5,
        "size": Vector3(1.8, 0.62, 4.5), "cabin": Vector3(1.55, 0.58, 2.3), "cabin_z": 0.15, "sill": -0.7,
        "hood": 0.26, "trunk": 0.18, "livery": "taxi",
        "wheel_radius": 0.34, "suspension": 40.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.95, 0.8, 0.1)],
    },
    "police": {
        "id": "police",
        "name": "Viatura (polícia)", "mass": 1400.0, "power": 2800.0, "gears": 5, "awd": false, "max_speed": 46.0, "steer": 0.5,
        "size": Vector3(1.8, 0.62, 4.5), "cabin": Vector3(1.55, 0.58, 2.3), "cabin_z": 0.15, "sill": -0.7,
        "hood": 0.26, "trunk": 0.18, "livery": "police",
        "wheel_radius": 0.34, "suspension": 42.0,
        "colors": [Color(0.93, 0.93, 0.94)],
    },
    "ambulance": {
        "id": "ambulance",
        "name": "Ambulância", "mass": 2300.0, "power": 2700.0, "gears": 5, "awd": false, "max_speed": 34.0, "steer": 0.45,
        "size": Vector3(2.0, 0.92, 5.0), "cabin": Vector3(1.9, 0.9, 3.7), "cabin_z": 0.35, "sill": -0.64,
        "box": true, "livery": "ambulance",
        "wheel_radius": 0.38, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94)],
    },
    "bus": {
        "id": "bus",
        "name": "Ônibus urbano", "mass": 9000.0, "power": 7000.0, "gears": 4, "awd": false, "max_speed": 24.0, "steer": 0.35,
        "size": Vector3(2.5, 1.1, 10.5), "cabin": Vector3(2.4, 1.15, 10.0), "cabin_z": 0.0, "sill": -0.45,
        "box": true, "livery": "bus",
        "wheel_radius": 0.5, "suspension": 30.0,
        "colors": [Color(0.88, 0.88, 0.9), Color(0.9, 0.9, 0.92)],
    },
    "sport": {
        "id": "sport",
        "name": "Esportivo", "mass": 1100.0, "power": 3000.0, "gears": 6, "awd": false, "max_speed": 55.0, "steer": 0.5,
        "size": Vector3(1.85, 0.56, 4.3), "cabin": Vector3(1.5, 0.42, 1.9), "cabin_z": 0.25, "sill": -0.72,
        "hood": 0.3, "trunk": 0.14, "spoiler": true,
        "wheel_radius": 0.34, "suspension": 55.0,
        "colors": [Color(0.65, 0.06, 0.06), Color(0.95, 0.75, 0.1), Color(0.1, 0.3, 0.8)],
    },
    "coupe": {
        "id": "coupe",
        "name": "Cupê", "mass": 1250.0, "power": 2800.0, "gears": 6, "awd": false, "max_speed": 48.0, "steer": 0.5,
        "size": Vector3(1.8, 0.52, 4.4), "cabin": Vector3(1.5, 0.45, 1.8), "cabin_z": 0.2, "sill": -0.72,
        "hood": 0.3, "trunk": 0.1,
        "wheel_radius": 0.34, "suspension": 45.0,
        "colors": [Color(0.65, 0.06, 0.06), Color(0.07, 0.07, 0.08), Color(0.75, 0.76, 0.78), Color(0.1, 0.18, 0.4)],
    },
    "wagon": {
        "id": "wagon",
        "name": "Perua", "mass": 1400.0, "power": 2500.0, "gears": 5, "awd": false, "max_speed": 40.0, "steer": 0.5,
        "size": Vector3(1.8, 0.62, 4.6), "cabin": Vector3(1.55, 0.6, 2.8), "cabin_z": 0.4, "sill": -0.7,
        "hood": 0.24, "trunk": 0.02,
        "wheel_radius": 0.34, "suspension": 40.0,
        "colors": [Color(0.75, 0.76, 0.78), Color(0.93, 0.93, 0.94), Color(0.35, 0.36, 0.38), Color(0.12, 0.35, 0.2)],
    },
    "minivan": {
        "id": "minivan",
        "name": "Minivan", "mass": 1700.0, "power": 2700.0, "gears": 5, "awd": false, "max_speed": 36.0, "steer": 0.48,
        "size": Vector3(1.9, 0.78, 4.7), "cabin": Vector3(1.75, 0.7, 3.0), "cabin_z": 0.3, "sill": -0.66,
        "hood": 0.16, "trunk": 0.04,
        "wheel_radius": 0.36, "suspension": 38.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.75, 0.76, 0.78), Color(0.07, 0.07, 0.08), Color(0.1, 0.18, 0.4)],
    },
    "compact_suv": {
        "id": "compact_suv",
        "name": "SUV compacto", "mass": 1500.0, "power": 2600.0, "gears": 5, "awd": false, "max_speed": 38.0, "steer": 0.48,
        "size": Vector3(1.8, 0.75, 4.2), "cabin": Vector3(1.6, 0.6, 2.4), "cabin_z": 0.3, "sill": -0.64,
        "hood": 0.2, "trunk": 0.05,
        "wheel_radius": 0.37, "suspension": 40.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.35, 0.36, 0.38), Color(0.65, 0.06, 0.06), Color(0.85, 0.4, 0.08)],
    },
    "mini": {
        "id": "mini",
        "name": "Mini urbano", "mass": 800.0, "power": 1500.0, "gears": 5, "awd": false, "max_speed": 32.0, "steer": 0.55,
        "size": Vector3(1.55, 0.52, 3.2), "cabin": Vector3(1.35, 0.55, 1.8), "cabin_z": 0.15, "sill": -0.72,
        "hood": 0.15, "trunk": 0.04,
        "wheel_radius": 0.29, "suspension": 36.0,
        "colors": [Color(0.95, 0.75, 0.1), Color(0.65, 0.06, 0.06), Color(0.93, 0.93, 0.94), Color(0.1, 0.18, 0.4)],
    },
    "muscle": {
        "id": "muscle",
        "name": "Cupê clássico", "mass": 1500.0, "power": 3300.0, "gears": 5, "awd": false, "max_speed": 52.0, "steer": 0.48,
        "size": Vector3(1.9, 0.58, 4.9), "cabin": Vector3(1.5, 0.45, 1.9), "cabin_z": 0.35, "sill": -0.7,
        "hood": 0.32, "trunk": 0.12,
        "wheel_radius": 0.36, "suspension": 48.0,
        "colors": [Color(0.07, 0.07, 0.08), Color(0.85, 0.4, 0.08), Color(0.1, 0.18, 0.4), Color(0.93, 0.93, 0.94)],
    },
    "large_pickup": {
        "id": "large_pickup",
        "name": "Picape cabine dupla", "mass": 2300.0, "power": 3300.0, "gears": 5, "awd": true, "max_speed": 38.0, "steer": 0.44,
        "size": Vector3(2.05, 0.85, 5.5), "cabin": Vector3(1.85, 0.65, 2.2), "cabin_z": -0.5, "sill": -0.58,
        "hood": 0.2, "trunk": 0.05, "bed": true,
        "wheel_radius": 0.42, "suspension": 38.0,
        "colors": [Color(0.07, 0.07, 0.08), Color(0.93, 0.93, 0.94), Color(0.75, 0.76, 0.78), Color(0.65, 0.06, 0.06)],
    },
    "microbus": {
        "id": "microbus",
        "name": "Micro-ônibus", "mass": 3200.0, "power": 3800.0, "gears": 5, "awd": false, "max_speed": 30.0, "steer": 0.42,
        "size": Vector3(2.1, 1.0, 6.2), "cabin": Vector3(2.0, 1.0, 5.0), "cabin_z": 0.2, "sill": -0.58,
        "box": true,
        "wheel_radius": 0.4, "suspension": 34.0,
        "colors": [Color(0.93, 0.93, 0.94), Color(0.95, 0.75, 0.1), Color(0.1, 0.18, 0.4)],
    },
}
