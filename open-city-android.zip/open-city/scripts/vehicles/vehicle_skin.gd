extends RefCounted
## Skins de veículos por pasta. Veja docs/SKINS.md.
##
## Para cada tipo de veículo (id em vehicle_data.gd), o jogo procura na pasta
## res://assets/vehicles/<id>/ :
##   model.glb  (ou model.gltf)  -> troca a carroceria por um modelo 3D seu
##   skin.png   (ou .jpg/.webp)  -> aplica uma imagem como pintura (repete em padrão)
## Se a pasta não tiver nada, o carro continua com o visual gerado por código.

const FOLDER := "res://assets/vehicles/"
const MODEL_NAMES := ["model.glb", "model.gltf"]
const TEXTURE_NAMES := ["skin.png", "skin.jpg", "skin.jpeg", "skin.webp"]

## Modelos .glb costumam olhar para +Z. O jogo usa a frente em -Z, então giramos 180 graus.
## Se o seu modelo aparecer de ré, troque para false.
const MODEL_FACES_PLUS_Z := true

## Tamanho (em metros) que a imagem de pintura leva para se repetir.
const TEXTURE_TILE_METERS := 4.0

static var _info_cache := {}
static var _tex_cache := {}


static func _find(id: String, names: Array) -> String:
    for n: String in names:
        var path := FOLDER + id + "/" + n
        if ResourceLoader.exists(path):
            return path
    return ""


# ------------------------------------------------------------ pintura (imagem)

static func texture_for(id: String) -> Texture2D:
    if id == "":
        return null
    if _tex_cache.has(id):
        return _tex_cache[id]
    var tex: Texture2D = null
    var path := _find(id, TEXTURE_NAMES)
    if path != "":
        var res = load(path)
        if res is Texture2D:
            tex = res
    _tex_cache[id] = tex
    return tex


## A imagem é projetada nos três eixos (triplanar), então funciona sem mapeamento UV.
static func apply_texture(mat: StandardMaterial3D, tex: Texture2D) -> void:
    mat.albedo_texture = tex
    mat.albedo_color = Color.WHITE
    mat.uv1_triplanar = true
    mat.uv1_world_triplanar = false
    var s := 1.0 / TEXTURE_TILE_METERS
    mat.uv1_scale = Vector3(s, s, s)
    mat.texture_repeat = true


# ------------------------------------------------------------ modelo 3D (.glb)

static func has_model(id: String) -> bool:
    return not _info(id).is_empty()


## true se o modelo já tem rodas próprias (nó com "wheel", "roda", "tire" ou "pneu" no nome).
## Nesse caso o jogo não desenha as rodas geradas por código.
static func has_own_wheels(id: String) -> bool:
    var info := _info(id)
    return not info.is_empty() and bool(info["wheels"])


## Cria o modelo já girado, escalado e posicionado para ocupar o lugar da carroceria.
static func instance_model(id: String, data: Dictionary) -> Node3D:
    var info := _info(id)
    if info.is_empty():
        return null
    var scene: PackedScene = info["scene"]
    var inst = scene.instantiate()
    if not (inst is Node3D):
        inst.free()
        return null
    _orient(inst)
    var box: AABB = info["aabb"]
    var size: Vector3 = data["size"]
    var s := size.z / maxf(box.size.z, 0.001)
    var center := box.position + box.size * 0.5
    var bottom: float = float(data["sill"])
    if bool(info["wheels"]):
        bottom = -0.5 - float(data["wheel_radius"])
    var holder := Node3D.new()
    holder.name = "SkinModel"
    holder.scale = Vector3(s, s, s)
    holder.position = Vector3(-center.x * s, bottom - box.position.y * s, -center.z * s)
    holder.add_child(inst)
    return holder


static func _orient(inst: Node3D) -> void:
    if MODEL_FACES_PLUS_Z:
        inst.rotation.y += PI


static func _info(id: String) -> Dictionary:
    if id == "":
        return {}
    if _info_cache.has(id):
        return _info_cache[id]
    var info := {}
    var path := _find(id, MODEL_NAMES)
    if path != "":
        var res = load(path)
        if res is PackedScene:
            var inst = (res as PackedScene).instantiate()
            if inst is Node3D:
                _orient(inst)
                var out: Array = []
                _collect_aabb(inst, Transform3D.IDENTITY, out)
                if not out.is_empty():
                    info = {"scene": res, "aabb": out[0], "wheels": _has_wheel_nodes(inst)}
                else:
                    push_warning("Skin de veículo '%s': o modelo não tem nenhuma malha." % id)
            inst.free()
    _info_cache[id] = info
    return info


static func _collect_aabb(node: Node, parent_xf: Transform3D, out: Array) -> void:
    var xf := parent_xf
    if node is Node3D:
        xf = parent_xf * (node as Node3D).transform
    if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
        var box: AABB = xf * (node as MeshInstance3D).mesh.get_aabb()
        if out.is_empty():
            out.append(box)
        else:
            out[0] = (out[0] as AABB).merge(box)
    for child in node.get_children():
        _collect_aabb(child, xf, out)


static func _has_wheel_nodes(node: Node) -> bool:
    var n := String(node.name).to_lower()
    if n.contains("wheel") or n.contains("roda") or n.contains("tire") or n.contains("pneu"):
        return true
    for child in node.get_children():
        if _has_wheel_nodes(child):
            return true
    return false
