extends RefCounted
## Pessoa detalhada montada em código, com esqueleto de verdade (Skeleton3D) e UMA malha
## com pele (1 draw call por pessoa): cabeça com rosto (olhos, sobrancelhas, nariz, orelhas,
## boca), cabelo/boné, pescoço, tronco, ombros, braços e pernas com cotovelo e joelho,
## mãos e sapatos. Os pés ficam no chão (origem no pé). Formas arredondadas por anéis elípticos.

const GeoScript := preload("res://scripts/core/geo.gd")

const HIPS := 0
const SPINE := 1
const HEAD := 2
const THIGH_L := 3
const SHIN_L := 4
const THIGH_R := 5
const SHIN_R := 6
const UARM_L := 7
const FARM_L := 8
const UARM_R := 9
const FARM_R := 10

# [nome, osso pai, posição global da articulação]
const BONES := [
    ["hips", -1, Vector3(0.0, 0.95, 0.0)],
    ["spine", 0, Vector3(0.0, 1.05, 0.0)],
    ["head", 1, Vector3(0.0, 1.54, 0.0)],
    ["thigh_l", 0, Vector3(-0.095, 0.93, 0.0)],
    ["shin_l", 3, Vector3(-0.095, 0.52, 0.0)],
    ["thigh_r", 0, Vector3(0.095, 0.93, 0.0)],
    ["shin_r", 5, Vector3(0.095, 0.52, 0.0)],
    ["uarm_l", 1, Vector3(-0.2, 1.46, 0.0)],
    ["farm_l", 7, Vector3(-0.2, 1.18, 0.0)],
    ["uarm_r", 1, Vector3(0.2, 1.46, 0.0)],
    ["farm_r", 9, Vector3(0.2, 1.18, 0.0)],
]

const SKIN_TONES := [Color(0.95, 0.78, 0.65), Color(0.85, 0.65, 0.5), Color(0.68, 0.48, 0.35), Color(0.5, 0.34, 0.24), Color(0.36, 0.24, 0.17)]
const SHIRTS := [Color(0.8, 0.2, 0.2), Color(0.2, 0.4, 0.8), Color(0.9, 0.9, 0.9), Color(0.2, 0.6, 0.3), Color(0.9, 0.7, 0.2), Color(0.5, 0.2, 0.6), Color(0.15, 0.15, 0.18), Color(0.85, 0.5, 0.6)]
const PANTS := [Color(0.15, 0.2, 0.35), Color(0.2, 0.2, 0.22), Color(0.45, 0.38, 0.28), Color(0.3, 0.3, 0.5), Color(0.55, 0.55, 0.58)]
const HAIRS := [Color(0.08, 0.06, 0.05), Color(0.3, 0.2, 0.12), Color(0.7, 0.55, 0.3), Color(0.5, 0.5, 0.5), Color(0.45, 0.15, 0.1)]
const HATS := [Color(0.8, 0.2, 0.2), Color(0.15, 0.2, 0.35), Color(0.9, 0.9, 0.9), Color(0.2, 0.2, 0.2)]

static var _material: StandardMaterial3D


static func _mat() -> StandardMaterial3D:
    if _material == null:
        _material = StandardMaterial3D.new()
        _material.vertex_color_use_as_albedo = true
        _material.roughness = 0.85
        _material.cull_mode = BaseMaterial3D.CULL_DISABLED
    return _material


static func random_outfit() -> Dictionary:
    var hat: Variant = null
    if randf() < 0.2:
        hat = HATS.pick_random()
    return {
        "skin": SKIN_TONES.pick_random(),
        "shirt": SHIRTS.pick_random(),
        "pants": PANTS.pick_random(),
        "hair": HAIRS.pick_random(),
        "shoe": Color(0.08, 0.08, 0.09),
        "long_hair": randf() < 0.4,
        "short_sleeves": randf() < 0.5,
        "shorts": randf() < 0.2,
        "hat": hat,
        "scale": randf_range(0.92, 1.08),
        "backpack": false,
    }


static func _r(y: float, rx: float, rz: float, cx: float = 0.0, cz: float = 0.0) -> Dictionary:
    return {"y": y, "rx": rx, "rz": rz, "cx": cx, "cz": cz}


static func _bone(st: SurfaceTool, index: int) -> void:
    st.set_bones(PackedInt32Array([index, 0, 0, 0]))
    st.set_weights(PackedFloat32Array([1.0, 0.0, 0.0, 0.0]))


## Cria a pessoa dentro de `parent`. Retorna {"root", "skeleton"}.
static func build(parent: Node3D, outfit: Dictionary, far_cull: float = 0.0) -> Dictionary:
    var skin: Color = outfit["skin"]
    var shirt: Color = outfit["shirt"]
    var pants: Color = outfit["pants"]
    var hair: Color = outfit["hair"]
    var shoe: Color = outfit["shoe"]
    var short_sleeves: bool = outfit.get("short_sleeves", false)
    var shorts: bool = outfit.get("shorts", false)
    var hat: Variant = outfit.get("hat", null)

    var root := Node3D.new()
    root.scale = Vector3.ONE * float(outfit.get("scale", 1.0))
    parent.add_child(root)

    # ---- esqueleto
    var skeleton := Skeleton3D.new()
    root.add_child(skeleton)
    for b in BONES:
        var idx := skeleton.add_bone(str(b[0]))
        skeleton.set_bone_parent(idx, int(b[1]))
    for i in BONES.size():
        var parent_index := int(BONES[i][1])
        var here: Vector3 = BONES[i][2]
        var local := here
        if parent_index >= 0:
            var up: Vector3 = BONES[parent_index][2]
            local = here - up
        skeleton.set_bone_rest(i, Transform3D(Basis(), local))
    skeleton.reset_bone_poses()

    # ---- malha única com pesos por osso
    var st := GeoScript.new_st()
    st.set_skin_weight_count(SurfaceTool.SKIN_4_WEIGHTS)

    # quadril e tronco
    _bone(st, HIPS)
    GeoScript.ellipse_loft(st, [_r(0.84, 0.12, 0.09), _r(0.9, 0.155, 0.1), _r(0.98, 0.16, 0.105), _r(1.05, 0.15, 0.1)], 14, pants, false)
    _bone(st, SPINE)
    GeoScript.ellipse_loft(st, [_r(1.05, 0.15, 0.1), _r(1.14, 0.14, 0.095), _r(1.26, 0.16, 0.1), _r(1.38, 0.18, 0.11), _r(1.46, 0.19, 0.105), _r(1.52, 0.12, 0.08), _r(1.55, 0.05, 0.05)], 14, shirt, false)
    if outfit.get("backpack", false):
        GeoScript.box(st, Vector3(0.0, 1.07, 0.15), Vector3(0.28, 0.4, 0.13), Vector2.ONE, 0.0, Color(0.15, 0.15, 0.18), true, true, true)

    # pescoço, cabeça, rosto, cabelo / boné
    _bone(st, HEAD)
    GeoScript.ellipse_loft(st, [_r(1.52, 0.05, 0.05), _r(1.6, 0.045, 0.045)], 10, skin, false)
    GeoScript.ellipse_loft(st, [_r(1.59, 0.035, 0.04, 0.0, -0.015), _r(1.63, 0.065, 0.075, 0.0, -0.01), _r(1.69, 0.088, 0.098), _r(1.76, 0.092, 0.104, 0.0, 0.005), _r(1.83, 0.075, 0.09, 0.0, 0.01), _r(1.875, 0.035, 0.045, 0.0, 0.01)], 16, skin)
    GeoScript.sphere(st, Vector3(0.0, 1.695, -0.105), 1.0, 3, 8, skin.darkened(0.06), Vector3(0.014, 0.024, 0.022))
    for sx: float in [-1.0, 1.0]:
        GeoScript.sphere(st, Vector3(sx * 0.092, 1.7, 0.005), 1.0, 3, 8, skin, Vector3(0.012, 0.03, 0.022))
        GeoScript.sphere(st, Vector3(sx * 0.035, 1.72, -0.093), 1.0, 3, 8, Color(0.95, 0.95, 0.95), Vector3(0.015, 0.011, 0.008))
        GeoScript.sphere(st, Vector3(sx * 0.035, 1.72, -0.099), 1.0, 3, 8, Color(0.05, 0.05, 0.06), Vector3(0.007, 0.007, 0.004))
        GeoScript.box(st, Vector3(sx * 0.035, 1.742, -0.1), Vector3(0.034, 0.007, 0.008), Vector2.ONE, 0.0, hair, true, true, true)
    GeoScript.box(st, Vector3(0.0, 1.652, -0.097), Vector3(0.04, 0.006, 0.008), Vector2.ONE, 0.0, Color(0.55, 0.25, 0.25), true, true, true)
    GeoScript.ellipse_loft(st, [_r(1.762, 0.098, 0.11, 0.0, 0.006), _r(1.79, 0.1, 0.112, 0.0, 0.01), _r(1.84, 0.082, 0.098, 0.0, 0.012), _r(1.885, 0.04, 0.052, 0.0, 0.012)], 16, hair, true)
    if outfit.get("long_hair", false):
        GeoScript.ellipse_loft(st, [_r(1.76, 0.1, 0.112, 0.0, 0.01), _r(1.68, 0.105, 0.12, 0.0, 0.02), _r(1.58, 0.1, 0.115, 0.0, 0.03), _r(1.48, 0.085, 0.1, 0.0, 0.04)], 12, hair, false, 0.0, PI)
    if hat is Color:
        var hat_color: Color = hat
        GeoScript.ellipse_loft(st, [_r(1.79, 0.105, 0.118, 0.0, 0.008), _r(1.86, 0.1, 0.112, 0.0, 0.01), _r(1.905, 0.05, 0.06, 0.0, 0.01)], 16, hat_color, true)
        GeoScript.ellipse_loft(st, [_r(1.79, 0.105, 0.118, 0.0, 0.008), _r(1.788, 0.1, 0.17, 0.0, -0.05)], 12, hat_color, false, PI, TAU)

    # pernas, cada uma com coxa, canela e sapato
    for side in 2:
        var sx := -1.0 if side == 0 else 1.0
        var thigh_bone := THIGH_L if side == 0 else THIGH_R
        var shin_bone := SHIN_L if side == 0 else SHIN_R
        var cx := sx * 0.095
        _bone(st, thigh_bone)
        GeoScript.ellipse_loft(st, [_r(0.97, 0.088, 0.095, cx), _r(0.86, 0.085, 0.092, cx), _r(0.72, 0.074, 0.08, cx)], 12, pants, false)
        GeoScript.ellipse_loft(st, [_r(0.72, 0.074, 0.08, cx), _r(0.55, 0.062, 0.07, cx)], 12, skin if shorts else pants, false)
        _bone(st, shin_bone)
        var shin_color := skin if shorts else pants
        GeoScript.ellipse_loft(st, [_r(0.55, 0.062, 0.07, cx), _r(0.4, 0.058, 0.068, cx, 0.012), _r(0.25, 0.046, 0.054, cx, 0.006), _r(0.09, 0.04, 0.045, cx)], 12, shin_color, false)
        GeoScript.sphere(st, Vector3(cx, 0.045, -0.035), 1.0, 4, 10, shoe, Vector3(0.05, 0.045, 0.13))

    # braços, cada um com braço, antebraço, mão e ombro
    for side in 2:
        var sx := -1.0 if side == 0 else 1.0
        var upper_bone := UARM_L if side == 0 else UARM_R
        var fore_bone := FARM_L if side == 0 else FARM_R
        var cx := sx * 0.2
        _bone(st, upper_bone)
        GeoScript.sphere(st, Vector3(cx, 1.46, 0.0), 0.065, 4, 10, shirt)
        GeoScript.ellipse_loft(st, [_r(1.46, 0.052, 0.052, cx), _r(1.36, 0.05, 0.05, cx)], 10, shirt, false)
        GeoScript.ellipse_loft(st, [_r(1.36, 0.05, 0.05, cx), _r(1.2, 0.04, 0.04, cx)], 10, shirt if not short_sleeves else skin, false)
        _bone(st, fore_bone)
        GeoScript.ellipse_loft(st, [_r(1.2, 0.04, 0.04, cx), _r(1.07, 0.036, 0.036, cx), _r(0.96, 0.028, 0.03, cx)], 10, skin if short_sleeves else shirt, false)
        GeoScript.ellipse_loft(st, [_r(0.96, 0.028, 0.03, cx), _r(0.94, 0.03, 0.032, cx)], 10, skin, false)
        GeoScript.sphere(st, Vector3(cx, 0.915, 0.0), 1.0, 4, 10, skin, Vector3(0.032, 0.052, 0.026))

    var mesh := ArrayMesh.new()
    st.commit(mesh)
    mesh.surface_set_material(0, _mat())
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.skin = skeleton.create_skin_from_rest_transforms()
    mi.extra_cull_margin = 0.5
    if far_cull > 0.0:
        mi.visibility_range_end = far_cull
    skeleton.add_child(mi)

    return {"root": root, "skeleton": skeleton}


static func _rot(skeleton: Skeleton3D, bone: int, angle: float) -> void:
    skeleton.set_bone_pose_rotation(bone, Quaternion(Vector3.RIGHT, angle))


## phase = fase do passo (rad), amount = 0 (parado) a ~1,4 (corrida).
static func animate(rig: Dictionary, phase: float, amount: float) -> void:
    var skeleton: Skeleton3D = rig["skeleton"]
    var s := sin(phase) * 0.75 * amount
    var flex_l := (0.35 + 0.35 * sin(phase - 1.2)) * amount
    var flex_r := (0.35 + 0.35 * sin(phase + PI - 1.2)) * amount
    _rot(skeleton, THIGH_L, s)
    _rot(skeleton, SHIN_L, -flex_l)
    _rot(skeleton, THIGH_R, -s)
    _rot(skeleton, SHIN_R, -flex_r)
    _rot(skeleton, UARM_L, -s * 0.8)
    _rot(skeleton, FARM_L, 0.2 * amount + 0.25 * maxf(s, 0.0))
    _rot(skeleton, UARM_R, s * 0.8)
    _rot(skeleton, FARM_R, 0.2 * amount + 0.25 * maxf(-s, 0.0))
    skeleton.set_bone_pose_rotation(SPINE, Quaternion(Vector3.UP, s * 0.1))
